package diamondprob;

interface One{
   default void disp() {
		System.out.println("Display method of interface One");
	}
	
}
interface Two{
	default void disp()
	{
		System.out.println("DIsplay method of interface Two");
	}
}

public class DiamondProblem implements One, Two{

	public void disp()
	{
		One.super.disp();
		Two.super.disp();
		
	}
	public static void main(String[] args) {
	
    DiamondProblem dp = new DiamondProblem();
    dp.disp();
	}

}
