package constructortypes;

class Nonpara{
	int sno;
	String name;
	Nonpara()
	{
		System.out.println("It is a default constructor!!");
	}
}
class Para{
	int sno;
	String name;
    Para(int sno, String name){
    	this.sno=sno;
    	this.name=name;
    	System.out.println("It is a parameterized constructor!!");
    }
    public void getsen()
    {
    	System.out.println("Serial number and name is : "+sno+ " and "+name);
    }
}
public class Contypes {

	public static void main(String[] args) {
		System.out.println("Default constructor : ");
		System.out.println();
		Nonpara np = new Nonpara();
		System.out.println("Before assigning values to variables from main method");
		System.out.println("Serial number : "+np.sno);
		System.out.println("Name : "+np.name);
		System.out.println("After assigning values to variables from main method");
		np.sno=1;
		np.name="First type of constructor";
		System.out.println("Serial number : "+np.sno);
		System.out.println("Name : "+np.name);
		System.out.println();
		System.out.println("Paramaterized constructor : ");
		System.out.println();
		Para pc = new Para(1,"Second type of constructor");
		System.out.println("Serial number : "+pc.sno);
		System.out.println("Name : "+pc.name);
		pc.getsen();
		
		

	}

}
