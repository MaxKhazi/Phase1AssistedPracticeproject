package innerclass;

public class innerclassa2 {
private String msg="Private string variable ";
void dis(){  
		 
class Inner
{  
			void msg(){
		   System.out.println(msg);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.msg();  
	 }  

	 
	public static void main(String[] args) {
		innerclassa2  ic2 =new innerclassa2 ();  
		ic2.dis();  
		}
	}

		
