package innerclass;

public class Innerclassa1 {
  private String mg="Private string variable";
  
  class incl{
	  void ic()
	  {
		  System.out.println(mg+" Inside a inner class!!");
	  }
  }
	public static void main(String[] args) {
		Innerclassa1 icc = new Innerclassa1();
		Innerclassa1.incl inc = icc.new incl();
		inc.ic();
		
		
		
	}
}
