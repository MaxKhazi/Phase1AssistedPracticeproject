package innerclass;

abstract class anoninclass
{
   public abstract void msg();
		}


public class Anonymousinnerclass{

	public static void main(String[] args) {
	anoninclass i = new anoninclass() {

		 public void msg() {
		            System.out.println("This is anonymous inner class");
		         }
		      };
		      i.msg();
		   }
		}


