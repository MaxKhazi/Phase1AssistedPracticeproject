package diffmethods;

abstract class ab{
	abstract void  amethod();
	
}
class B extends ab{
	void amethod() {
		System.out.println("This is an Abstract method ");
	}
	
}
class C {
	public int add(int a, int b) {
		return a+b;
	}
	
}
class ovload{
	public int op(int x, int y) {
		return x*y;
	}
	public int op(int z) {
		return z*z;
	}
	
}

public class methods {
	public static void  smethod() {
		System.out.println("It is a static method inside  main class");
	}
	void ss() {
		System.out.println("Non static method inside main class");
	}
	int val = 10;
	int cv(int val)
	{
		val = val*10/100;
		return(val);
	}
	public static void main(String [] args) {
		System.out.println("Implementations of methods and ways of calling a method");
		System.out.println();
		B b = new B();
		b.amethod();
		C c = new C();
		int x = c.add(2, 5);
		System.out.println("Non static method for addition "+x);
		smethod();
		methods mm = new methods();
		mm.ss();
		System.out.println("Before cv method "+mm.val);
		mm.cv(130);
		System.out.println("After cv method "+mm.val);
		System.out.println();
		System.out.println("Method overloading");
		System.out.println();
		ovload ov = new ovload();
		int mul = ov.op(45,2);
		int s =  ov.op(7);
		System.out.println("Multiplication : "+mul);
		System.out.println("Square : "+s);
		
		
	}

}
