package oops;
class Encap
{ 
	private String Moviename; 
    private int num; 
    private String year;
    private int castnum;
    
    public String getMoviename()
    { 
      return Moviename; 
    } 
   public int getnum()
   {
	   return num;
   }
   public String getyear() {
	   return year;
   }
   public int getcastnum(){
	   return castnum;
   }
    public void setMoviename(String newMoviename) 
    { 
      Moviename = newMoviename; 
    } 
    public void setnum(int newnum ) {
    	num = newnum;
    } 
    public void setyear(String newyear) {
    	year = newyear;
    }
    public void setcastnum(int newcastnum) {
    	castnum = newcastnum;
    }
}
public class Encapsulation
{     
    public static void main (String[] args)  
    { 
        Encap en = new Encap(); 
        en.setMoviename("Identity");
        en.setnum(1);
        en.setyear("2003");
        en.setcastnum(10);
        System.out.println("Movie : "+en.getMoviename());
        System.out.println("Movie serial number : "+en.getnum());
        System.out.println("Movie release year : "+en.getyear());
        System.out.println("Movie cast number : "+en.getcastnum());
           
    } 
}
