package oops;

public class Bikeobjectclass {
int no;
String name;
String color;
int speed;
 public Bikeobjectclass(int no, String name, String color, int speed) {
	 this.no=no;
	 this.name=name;
	 this.color=color;
	 this.speed=speed;
 }
 public int getno() {
	 return no;
 }
 public String getname() {
	 return name;
 }
 public String getcolor()
 {
	 return color;
 }
 public int getspeed()
 {
	 return speed;
 }

 public String toString()
 {
	 return ("Bike number : "+this.getno()+", Bike name : "+this.getname()+", Bike color : "+this.getcolor()+" and Bike speed : "+this.getspeed());
 }
	public static void main(String[] args) {
	Bikeobjectclass bike = new Bikeobjectclass(123,"Yamaha","Black",350);
   System.out.println(bike.toString());
	}

}
