package oops;

public class Polymorphismex {
	public int opr(int x, int y) {
		return x+y;
	}
	public double opr(double x, float y, int z) {
		return x+y+z;
	}
	public float opr(float x, float y) {
		return x-y;
	}
	public int opr(int x) {
		return x*x;
	}

	public static void main(String[] args) {
	Polymorphismex p = new Polymorphismex();
	System.out.println("Square "+p.opr(4));
   System.out.println("Addition: "+	p.opr(2.33,4.02f,12));
	System.out.println("Sub : "+p.opr(2.3f,1.3f));
	System.out.println("Square : "+p.opr(8));

	}

}
