package threadcreation;

public class Runnablethread implements Runnable {
	public static int mycount =0;
	public Runnablethread() {
		
	}
	public void run()
	{
		while(Runnablethread.mycount<=10) {
			try {
				System.out.println("Exp Thread: " +(++Runnablethread.mycount));
				Thread.sleep(100);
			}
			catch(InterruptedException iex) {
				System.out.println("Excaption in thread:" +iex.getMessage());
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("Starting Mian thread..");
		Runnablethread rt = new Runnablethread();
		Thread t = new Thread(rt);
		t.start();
		while(Runnablethread.mycount<=10) {
			try {
				System.out.println("Main thread: "+(++Runnablethread.mycount));
				Thread.sleep(100);
			}
			catch(InterruptedException iex) {
				System.out.println("Exception in main thread: "+iex.getMessage());
			}
		}
		System.out.println("End of Main Thread...");
		
	}

		
	

}
