package threadcreation;

public class Threadcreate extends Thread{

	public void run() {
		System.out.println("Concurrent thread starting running");
	}
	public static void main(String[] args) {
		Threadcreate tc = new Threadcreate();
		tc.start();
	}

}
