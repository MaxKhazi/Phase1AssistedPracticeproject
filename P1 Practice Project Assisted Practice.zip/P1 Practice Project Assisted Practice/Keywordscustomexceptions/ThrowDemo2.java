package Keywordscustomexceptions;

public class ThrowDemo2 {
	
	void Division() throws ArithmeticException{
		int a =45;
		int b=0; 
		int rs;
		rs=a/b;
		System.out.println(" Result : "+rs);
	}

	public static void main(String[] args) {
	ThrowDemo2 td = new ThrowDemo2();
	try {
		td.Division();
	}
	catch(ArithmeticException Ex) {
		System.out.println(" Error : "+Ex.getMessage());
	}
	System.out.println("\n \t End of program. ");
	

	}

}
