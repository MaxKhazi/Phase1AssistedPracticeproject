package Keywordscustomexceptions;

public class FinallyBloackDemo {

	public static void main(String[] args) {
	int a=45, b=0, result=0;
	try {
		result=a/b;
	}
	catch(ArithmeticException Ex) {
		System.out.println("\n Error : "+Ex.getMessage());
		
	}
	finally {
		System.out.println("\n Results "+result);
	}

	}

}
