package accessmodifiers;

public class publicmod {

	public int add(int a, int b) {
		return a+b;
	}

}
