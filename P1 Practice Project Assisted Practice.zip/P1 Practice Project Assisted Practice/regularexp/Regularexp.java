package regularexp;

import java.util.regex.*;

public class Regularexp {

public static void main(String[] args) {

	String pa = "[a-z,A-Z,@,.]+";
	String check = "demoD@gmail.com";
	Pattern p = Pattern.compile(pa);
	Matcher c = p.matcher(check);
	
	while (c.find())
      	System.out.print( check.substring( c.start(), c.end() ) );
	}
}


