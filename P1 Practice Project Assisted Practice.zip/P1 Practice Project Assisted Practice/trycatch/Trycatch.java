package trycatch;

public class Trycatch {

	public static void main(String[] args) {
	int a = 12;
	int b =0;
	int c =0;
	
	try {
		c=a/b;
	}
	catch(Exception e) {
		System.out.println("Can't divide any number by 0");
	}
	finally {
		System.out.println("b should always be greater than 0");
	}

	}

}
