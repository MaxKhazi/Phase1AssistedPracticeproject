package stringsmeth;

public class Stringmethods {

	public static void main(String[] args) {
		String s1 = new String("String Methods in Java");
		System.out.println(s1);
		System.out.println();
		System.out.println(s1.length());
		String s2 = new String(" language");
		System.out.println(s1.concat(s2));
		System.out.println(s2.substring(1,4));
		String s3 ="Welcome";
		String s4 ="Welcomee";
		System.out.println(s3.compareTo(s4));
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(s3.replace('W','B'));
		String s5="QWERty";
		String s6="qwerty";
		System.out.println(s5.equals(s6));
		String g = "";
		System.out.println(g.isEmpty());
		System.out.println();
		
		System.out.println("String buffer");
		System.out.println();
		StringBuffer s = new StringBuffer("Hi everyone");
		s.append(", good morning!");
		System.out.println(s);
		s.insert(13, 'G');
		System.out.println(s);
		s.replace(13,26,"GOOD MORNING");
		System.out.println(s);
		s.delete(0, 12);
		System.out.println(s);
		System.out.println();
		System.out.println("String builder");
		System.out.println();
		StringBuilder sb = new StringBuilder("New String");
		sb.append("for StringBuilder");
		System.out.println(sb);
		System.out.println(sb.delete(0, 1));
		System.out.println(sb.insert(0,"N"));
		System.out.println(sb.reverse());
		System.out.println();
		System.out.println("Strings to StringBuffer and StringBuilder");
		String sss = "Welcome";
		StringBuffer sbb = new StringBuffer(sss);
		System.out.println("String to StringBUffer");
		System.out.println(sbb);
		StringBuilder sabb = new StringBuilder(sss);
		sabb.append(" sir!");
		System.out.println();
		System.out.println("String to StringBuilder");
		System.out.println(sabb);
		}

}
