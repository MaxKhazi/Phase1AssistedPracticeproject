package collections;
import java.io.*;
import java.util.*;
public class Javacoll {

	public static void main(String[] args) {
	ArrayList<String> lang = new ArrayList<String>();
	lang.add("Java");
	lang.add("Python");
	lang.add("C++");
	lang.add("php");
	System.out.println("Programming languages using ArrayList :");
	System.out.println(lang);
	System.out.println("ArrayList contains Java : "+lang.contains("Java"));
	System.out.println("Index of php : "+lang.indexOf("php"));
	System.out.println();
	LinkedList <Double> num = new LinkedList<Double>();
	num.add(234.12);
	num.add(303.98);
	num.add(908.34);
	System.out.println("Numbers using LinkedList : ");
	Iterator<Double> itr = num.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
		System.out.println();
    Vector <String> vs = new Vector<String>();
    vs.add("Lenovo");
    vs.add("Dell");
    vs.add("Asus");
    vs.add("Hp");
    System.out.println("Laptop brands using vectors");
    System.out.println(vs);
    System.out.println();
    
   HashSet<Integer> hs=new HashSet<Integer>();  
   hs.add(200000);
   hs.add(300000);
   hs.add(770000);
   hs.add(400000);
   System.out.println("Salaries using hashset ");
   System.out.println(hs);
   System.out.println();
   LinkedHashSet<Integer> lhs =new LinkedHashSet<Integer>();  
   lhs.add(1234);
   lhs.add(98765);
   lhs.add(6574);
   lhs.add(345);
   System.out.println("Linked hashset");
   System.out.println(lhs);

    

	}

}

