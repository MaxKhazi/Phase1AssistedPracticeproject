package accessmodifiers;


public class protectmod {
 protected void prot() {
	 System.out.println("This is protected access modifier");
	 
 }
}

