package accessmodifiers;

public class protectmod3 extends protectmod {

	public static void main(String[] args) {
		protectmod p = new protectmod();
		p.prot();
		//Protected can't be accessed outside the package.

	}

}
