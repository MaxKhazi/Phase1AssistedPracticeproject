package hashmap;
import java.util.*;

public class Hashmp {

	public static void main(String[] args) {
		HashMap <Integer,String> hp = new HashMap<Integer,String>();
		hp.put(1,"Lenovo");
		hp.put(2, "Dell");
		hp.put(3, "Hp");
		System.out.println("HashMap elements :");
		System.out.println(hp);
		System.out.println();
		Hashtable<String, Integer> ht = new Hashtable<String,Integer>();
		ht.put("Java", 11);
		ht.put("Python", 22);
		ht.put("C++",33);
		ht.put("php",44);
		System.out.println("Hashtable elements :");
	    for(Map.Entry n:ht.entrySet()){    
		System.out.println(n.getKey()+" "+n.getValue());    
		    }
	    System.out.println();
	    TreeMap<Float,String> mp=new TreeMap<Float,String>();    
	    mp.put(22.03f,"ReactJS");    
	    mp.put(34.87f,"Angular");    
	    mp.put(44.65f,"Django"); 
	    mp.put(55.32f,"Flask");
	    System.out.println("TreeMap elements :");  
	    for(Map.Entry l:mp.entrySet())
	    {    
	    System.out.println(l.getKey()+" "+l.getValue());    
	    }

		
		

	}

}
