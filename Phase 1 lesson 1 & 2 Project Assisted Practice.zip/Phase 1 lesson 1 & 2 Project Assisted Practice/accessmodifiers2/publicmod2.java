package accessmodifiers2;
import accessmodifiers.*;
public class publicmod2 {

	public static void main(String[] args) {
		publicmod pmd = new publicmod();
		int a = pmd.add(2,3);
		System.out.println("Addition of 2 numbers : "+a);

	}

}
