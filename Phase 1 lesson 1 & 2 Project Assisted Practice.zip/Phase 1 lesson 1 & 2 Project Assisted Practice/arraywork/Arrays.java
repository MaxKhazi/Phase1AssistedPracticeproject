package arraywork;
import java.util.Scanner;
public class Arrays {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Arrays.....");
	int a[] = {1,2,4,5,7};
	int s = a.length;
    for(int i=0; i<s; i++) {
    	System.out.print(a[i]+" ");
    }
    System.out.println();
    System.out.println("One dimentional array by giving user input..");
    System.out.println("Enter the number of array size :");
    int ss = sc.nextInt();
    System.out.println("Enter array elements : ");
    int a1[] = new int[ss];
    for(int i=0; i<ss; i++) {
    	a1[i]=sc.nextInt();
    }
    System.out.println(" Array elements are :  ");
    for(int j=0; j<ss; j++) {
    	System.out.println(a1[j]+" ");
    }
    
    System.out.println();
    System.out.println("Two dimentional arrays by giving user input..");
    System.out.println("Enter the number of rows :");
    int r = sc.nextInt();
    System.out.println("Enter the number of columns :");
    int c = sc.nextInt();
    System.out.println("Enter array 1 elements : ");
    int a2 [][] = new int[r][c];
    int a3[][] = new int[r][c];
    int cc[][] = new int[r] [c];
    for(int i=0; i<r; i++) {
    for(int j=0; j<c; j++) {
	  a2[i][j]=sc.nextInt();
    	}
    	
    }
    System.out.println("Enter array 2 elements : ");
    for(int i=0; i<r; i++) {
    for(int j=0; j<c; j++) {
	  a3[i][j]=sc.nextInt();
    	}
    	
    }
    System.out.println(" Array elements are :  ");
    for(int i=0; i<r; i++) {
    	for(int j=0; j<c; j++) {
    		cc[i][j] = a2[i][j]+a3[i][j];
    				}
    }
    System.out.println("Addtion of 2 arrays");
    for(int i=0; i<r; i++) {
    	for(int j=0; j<c; j++) {
    		System.out.print(cc[i][j]+" ");
    				}
    	System.out.println();
    }
	}

}
