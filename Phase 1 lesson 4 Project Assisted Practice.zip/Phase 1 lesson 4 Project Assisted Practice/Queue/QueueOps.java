package Queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueOps
{
         public static void main(String[] args) 
         {
         Queue<String> que = new LinkedList<>();
         que.add("C");
         que.add("C++");
         que.add("Java");
         que.add("Python");
         que.add("PhP");
         System.out.println("Queue is : " + que);
         System.out.println("Head of Queue : " + que.peek());
         que.remove();
         System.out.println("After removing Head of Queue : " + que);
         System.out.println("Size of Queue : " + que.size());
    	}
}

