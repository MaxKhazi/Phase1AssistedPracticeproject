package sumofnnumbersrange;

public class Rangeofnnumssum {

	public static void main(String[] args) {
	int arr[] = { 3, 7, 2, 5, 8, 9 }; 
    int L = 2;
    int R = 4;
    rangesum rs = new rangesum();
    int s = rs.rsum(arr,L,R);
    System.out.println("Sum of numbers between range "+L+" and "+R+ " is "+s);
	}

}
class  rangesum {
	public int rsum(int[] arr, int l , int r) {
		int sum=0;
		for(int i=l; i<=r; i++) {
			sum = sum + arr[i];
			}
		return sum;
	}
	
}
