package ArrayRotation;
import java.io.*;
import java.util.Scanner;
public class RotateArray {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter array size:");
	int s = sc.nextInt();
	int a[] = new int[s];
	System.out.println("Enter array elements : ");
	for (int i=0; i<s; i++) {
		a[i] = sc.nextInt();
	}
	System.out.println("Array elements :");
	for(int i=0;i<s; i++) {
		System.out.print(a[i]+" ");
	}
	System.out.println();
	System.out.println("After right rotation of an array by 5 steps..");
	int ss =5;
	rotate r = new rotate();
	r.rot(a,ss);
	
	}

}
class rotate{
	public void rot(int a[], int n) {
		int c=a.length-n;
		int s[] = new int[a.length];
		for(int i=c; i<a.length; i++) {
		System.out.print(a[i]+" ");
		}
		for(int j=0;j<c;j++) {
			System.out.print(a[j]+" ");
			
			
		}
		
		}
	}

