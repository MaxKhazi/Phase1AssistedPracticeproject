package com;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExternalElements {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\\\training\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/Prog2.html");
		wd.switchTo().alert().accept();
		wd.switchTo().alert().dismiss();
		wd.switchTo().alert().getText();
		wd.switchTo().alert().getText();
		wd.switchTo().alert().sendKeys("text");
		((WebDriver) wd.switchTo().alert()).close();
		wd.findElement(By.id("xyz")).sendKeys(Keys.CONTROL+"t");
		wd.findElement(By.id("xyz")).sendKeys(Keys.CONTROL+"w");
		
		
	}

}
