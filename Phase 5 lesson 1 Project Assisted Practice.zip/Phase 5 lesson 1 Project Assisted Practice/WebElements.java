package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebElements {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\\\training\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/Prog2.html");
		WebElement rb = wd.findElement(By.id("fruits"));
		Select fruits = new Select(wd.findElement(By.id("fruits")));
		fruits.selectByVisibleText("Banana");
		fruits.selectByIndex(1);
		wd.switchTo().frame("iframe1");
		wd.switchTo().frame("id of the element");
		

	}

}
