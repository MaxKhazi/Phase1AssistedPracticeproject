package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatingCSSAndXpath {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\\\training\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/Prog2.html");
		WebElement wb = wd.findElement(By.cssSelector("input#email"));
		System.out.println(wb.getText());
		WebElement tc = wd.findElement(By.cssSelector("input.inputtext"));
		System.out.println(tc.getText());
		WebElement ta = wd.findElement(By.cssSelector("input[name=lastName]"));
		System.out.println(ta.getText());
		WebElement tca = wd.findElement(By.cssSelector("input.inputtext[tabindex=1]"));
		System.out.println(tca.getText());
	    
	}

}
