package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatingWebPageElements {

	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver","C:\\\\training\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/Prog2.html");
		String titletag = wd.getTitle();
		System.out.println("Title : "+titletag);
	    WebElement il = wd.findElement(By.tagName("h2"));
	    System.out.println(il.getText());
	    WebElement id = wd.findElement(By.id("email"));
	    System.out.println(id.getText());
	    WebElement cl = wd.findElement(By.className("classname"));
	    System.out.println(cl.getText());
	    WebElement nm = wd.findElement(By.name("name"));
	    System.out.println(nm.getText());
	    WebElement pl = wd.findElement(By.partialLinkText("Google"));
	    System.out.println(pl.getText());
	    WebElement rx = wd.findElement(By.xpath("//*[@class='relativepath']"));
	    System.out.println(rx.getText());
	    WebElement ax = wd.findElement(By.xpath("html/body/div[1]/h4"));
	    System.out.println(ax.getText());
		
	}
}
