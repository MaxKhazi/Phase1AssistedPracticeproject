import { Component, OnInit } from "@angular/core";


@Component({
    selector:'classstyle',
    templateUrl: './classstyle.component.html'
    
})

export class buttonComponent implements OnInit{
    pageTitle: string = "Buttons"
    toggleImage(){
        alert("You have clicked on button");
    }
    ngOnInit():void{

    }
}
