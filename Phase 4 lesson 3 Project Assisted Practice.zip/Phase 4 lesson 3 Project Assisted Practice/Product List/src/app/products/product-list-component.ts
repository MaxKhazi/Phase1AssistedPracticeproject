import { Component, OnInit } from "@angular/core";


@Component({
    selector:'product-list',
    templateUrl: './product-list.component.html'
    
})

export class ProductListComponent implements OnInit{
    pageTitle: string = "Product List Page"
    name:string="Henry";
    num:number=123;
    ngOnInit():void{

    }
}
