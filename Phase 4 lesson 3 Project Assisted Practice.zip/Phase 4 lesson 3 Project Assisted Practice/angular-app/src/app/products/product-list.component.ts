import { Component } from '@angular/core';

@Component({
    selector:'product-list',
    templateUrl: './products-list.component.html'
})
export class ProductListComponent{
    pageTitle: String = "Product List Page"
}