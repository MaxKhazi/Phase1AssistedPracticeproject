import { Component, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-twowaybinding',
  templateUrl: './twowaybinding.component.html',
  styleUrls: ['./twowaybinding.component.css'],
  inputs:[`pdata`],
  outputs:[`cevent`]
})
export class TwowaybindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public pdata: string | undefined;
  cevent= new EventEmitter<string>();

  onChange(value:string){
    this.cevent.emit(value);


}
}
