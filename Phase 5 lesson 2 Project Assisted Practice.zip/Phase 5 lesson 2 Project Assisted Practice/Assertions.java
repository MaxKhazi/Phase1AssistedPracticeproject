package com.testannotations;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class Assertions {
	SoftAssert soft = new SoftAssert();
	WebDriver wd;
  @Test
  public void Launch() {
	  try {
		  Thread.sleep(3000);
	  }
	  catch(Exception e) {
		  e.printStackTrace();
	  }
  }
  @Test(dependsOnMethods= {"Launch"})
  public void Facebook() {
	  System.setProperty("webdriver.chrome.driver","C:\\training\\Selenium\\chromedriver_win32\\chromedriver.exe");
	   wd = new ChromeDriver();
	   try {
		   Thread.sleep(3000);
		   
	   }
	   catch(Exception e) {
		   e.printStackTrace();
	   }
	  wd.get("https://www.facebook.com");
	  soft.assertEquals("FB Title", wd.getTitle());
	  
  }
  @Test(dependsOnMethods= {"Facebook"})
  public void Login() {
	  wd.findElement(By.id("email")).sendKeys("max@gmail.com");
	  wd.findElement(By.id("pass")).sendKeys("12345");
	  wd.findElement(By.id("loginbutton")).click();
	  soft.assertAll();
	  try {
		  Thread.sleep(3000);
		  
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before Method");
	  
	   
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
