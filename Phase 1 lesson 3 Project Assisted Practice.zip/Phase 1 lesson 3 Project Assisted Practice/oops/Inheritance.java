package oops;

class Bicycle  
{ 
    public int gear; 
    public int speed; 
    public Bicycle(int gear, int speed) 
    { 
        this.gear = gear; 
        this.speed = speed; 
    } 
   public void starts()
   {
	   System.out.println("Bicycle starts");
	   System.out.println("Gear number : "+gear);
   }
    public void  moves() {
    	System.out.println("Bicycle moves in a moderate speed "+speed);
    }
} 
class MountainBike extends Bicycle  
{ 
    public int seatHeight; 
    public MountainBike(int gear,int speed,int startHeight) 
    {  
        super(gear, speed); 
        seatHeight = startHeight; 
    }
    public void moves()
    {
    	System.out.println("MountainBIke moves very fast at speed of "+speed+"km/hr");
    }
    public void setHeight(int newValue) 
    { 
        seatHeight = newValue; 
    } 
    @Override
    public String toString() 
    { 
        return (super.toString()+ 
                "\nseat height is "+seatHeight); 
    } 
}
public class Inheritance
{ 
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(5, 100, 25); 
        Bicycle b = new Bicycle(3,23);
        mb.starts();
        mb.moves();
        b.starts();
        b.moves();
    } 
}

