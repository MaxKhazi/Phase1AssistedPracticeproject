package exceptionhandling;

class excep extends Exception{
	String s1;
	excep(String s2){
		s1=s2;
	}
	public String toString() {
		return ("MyException Occured :"+s1);
	}
}

public class MyException {

	public static void main(String[] args) {
	try {
		System.out.println("Start of try block");
		throw new excep("Error message");
	}
	catch(excep exp) {
		System.out.println("Catch block");
		System.out.println(exp);
	}

	}

}
