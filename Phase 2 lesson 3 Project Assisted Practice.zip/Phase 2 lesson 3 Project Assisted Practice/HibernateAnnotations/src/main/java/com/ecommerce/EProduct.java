package com.ecommerce;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;  
import javax.persistence.Table;  
  
@Entity  
@Table(name= "products")   
public class EProduct {    
  
        @Id @GeneratedValue   
        @Column(name = "pid")
        private int ID;
        
        @Column(name = "pname")
        private String name;
        
        @Column(name = "price")
        private int price;
        
       
            
        public int getPID() {return this.ID; }
        public String getPName() { return this.name;}
        public int getPrice() { return this.price;}
      
        public void setPID(int pid) { this.ID = pid;}
        public void setName(String name) { this.name = name;}
        public void setPrice(int price) { this.price = price;}
         
}   
