package selectionSort;

import java.util.Arrays;
import java.util.Scanner;

public class SelectionSort {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array : ");
	int s = sc.nextInt();
	System.out.println("Enter array elements : ");
	int a[] = new int[s];
	for(int i=0; i<s; i++)
	{
		a[i]=sc.nextInt();
	}
	System.out.println("Array of elements : "+Arrays.toString(a));
    selectionSort(a);
    System.out.println("Sorted array elements after selection sort :");
    for(int i:a)
    {
       System.out.print(i+" ");
         }

	}
   
	public static void selectionSort(int[] arr)
	{
		for(int i=0;i<arr.length-1;i++)
		{
			int index =i;
            for(int j=i+1;j<arr.length;j++){
                if(arr[j]<arr[index]){
                 index =j;
                }
    }
            int smallNumber = arr[index];
            arr[index]= arr[i];
            arr[i]= smallNumber;
        }

    }

}
