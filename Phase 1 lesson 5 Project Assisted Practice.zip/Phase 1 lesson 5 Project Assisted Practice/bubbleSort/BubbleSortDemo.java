package bubbleSort;

import java.util.Arrays;
import java.util.Scanner;

public class BubbleSortDemo {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array : ");
	int s = sc.nextInt();
	System.out.println("Enter array elements : ");
	int a[] = new int[s];
	for(int i=0; i<s; i++)
	{
		a[i]=sc.nextInt();
	}
	System.out.println("Array of elements : "+Arrays.toString(a));
    bubbleSort(a);
	System.out.println("Sorted array elements after bubble sort :");
	for(int i:a)
	    {
	       System.out.print(i+" ");
	         }

		}

	
     public static void bubbleSort(int[] arr){
     int len = arr.length;
     int temp = 0;
     for(int i=0;i<len;i++)
     {
        for (int j=1;j<len;j++)
        {
            if(arr[j-1]>arr[j]){
            	
            temp = arr[j-1];
            arr[j-1]= arr[j];
            arr[j]= temp;

            }


        }

    }

}


}
