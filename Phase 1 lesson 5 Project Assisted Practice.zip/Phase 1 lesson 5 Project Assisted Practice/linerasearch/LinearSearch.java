package linerasearch;

import java.util.Arrays;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array : ");
	int s = sc.nextInt();
	System.out.println("Enter array elements : ");
	int a[] = new int[s];
	for(int i=0; i<s; i++) {
		a[i]=sc.nextInt();
	}
	System.out.println("Array of elements : "+Arrays.toString(a));
	System.out.println("Enter the element to be found: ");
	int e = sc.nextInt();
	int ee = lin(a,e);
	if(ee==-1) {
		System.out.println("Element "+e+" not found int the array");
	}
	else {
	System.out.println(e+" present at "+ee+" position");
	}
	

	}
	public static int lin(int a[],int e) {
		for(int i=0; i<a.length; i++) {
			if(a[i]==e) {
				return i;
			}
			
		}
		return -1;
		
		
	}

}

