package insertionSort;

import java.util.Arrays;
import java.util.Scanner;

public class InsertionSortDemo {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array : ");
	int s = sc.nextInt();
	System.out.println("Enter array elements : ");
	int a[] = new int[s];
	for(int i=0; i<s; i++)
	{
		a[i]=sc.nextInt();
	}
	System.out.println("Array of elements : "+Arrays.toString(a));
	insertionSort(a);
	System.out.println("Sorted array elements after insertion  sort :");
	for(int i:a)
		{
		  System.out.print(i+" ");
		}

			}
	
	public static void insertionSort(int[] a)
	{
		int len = a.length;
	    for(int j=1;j<len;j++){
	    int key = a[j];
	    int i=j-1;
	    while ((i>-1) && (a[i]>key))
	    {
             a[i+1]=a[i];
	        i--;
	    }
	    a[i+1]=key;
	         }

	    }

	}

