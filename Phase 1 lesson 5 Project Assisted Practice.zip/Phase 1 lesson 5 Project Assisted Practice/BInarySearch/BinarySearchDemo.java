package BInarySearch;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearchDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array : ");
		int s = sc.nextInt();
		System.out.println("Enter array elements : ");
		int a[] = new int[s];
		for(int i=0; i<s; i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("Array of elements : "+Arrays.toString(a));
		System.out.println("Enter the element to be found: ");
		int e = sc.nextInt();
		int l = a.length;
		binsearch(a,0,e,l);
		

	}
	public static void binsearch(int a[],int s, int k, int len) {
	int mv = (s+len)/2;
        while(s<=len){

            if(a[mv]<k){
                s = mv + 1;
            } else if(a[mv]==k){
                System.out.println("Element is found at index :"+mv);
                break;
            }else {
            	len=mv-1;
            }
            mv = (s+len)/2;
        }
            if(s>len){
             System.out.println("Element is not found");
            }
			

	}

}
