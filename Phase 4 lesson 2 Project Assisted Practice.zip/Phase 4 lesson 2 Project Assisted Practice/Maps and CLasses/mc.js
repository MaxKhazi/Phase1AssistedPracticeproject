var mp1 = new Map();
mp1.set("Fname","Hank");
mp1.set("Lname","Pim");
mp1.set("friend1","Scott");
mp1.set("friend2","Carter");
console.log(mp1);
console.log("Mp 1 has friend 3 ? "+mp1.has("friend3"));
console.log("Get value of key = friend 3- "+mp1.get("friend3"));
console.log("Get value of key = friend 3- "+mp1.get("friend3"));
console.log("Get value of key = fname - "+mp1.get("Fname"));
console.log("Get value of key = Lname- "+mp1.get("Lname"));
console.log("Get value of key = friend 1- "+mp1.get("friend1"));
console.log("Get value of key = friend 2- "+mp1.get("friend2"));
console.log("Delete element with key = friend 2- "+mp1.delete("friend2"));
mp1.clear();
console.log(mp1);
class Employee {
    constructor(id, name){
        this.id=id;
        this.name=name;

    }
    detail(){
       document.write(this.id+" "+this.name+"<br>")
}

}
var e1 = new Employee(101,"Micheal");
var e2 = new Employee(102,"Quill");

e1.detail();
e2.detail();
