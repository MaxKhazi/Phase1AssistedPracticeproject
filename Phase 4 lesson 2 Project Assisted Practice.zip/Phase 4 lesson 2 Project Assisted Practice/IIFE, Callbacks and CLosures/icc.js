//IIFE and CLosure
const empid = (function(){
    let count =0;
    return function(){
        ++count;
        return `emp${count}`;
    };
})();

console.log("New Employee IDs are listed here");
console.log("Alex: "+empid());
console.log("Dexter: "+empid());
console.log("Annie: "+empid());

//Callbacks
console.log("\n");//to start output from the next line
function fullName(fname,lname,Callback){
    console.log("My name is "+fname+" "+lname);
    Callback(lname);
}
var greeting = function(ln){
    console.log('Welcome '+ln);
};

fullName("Alex","Wilson",greeting);
console.log("\n");
fullName("Dexter","Johnson",greeting);
console.log("\n");
fullName("Annie","Butler",greeting);