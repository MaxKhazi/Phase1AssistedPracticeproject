function Employee(name, design, yearofBirth){
    this.name = name;
    this.design = design;
    this.yearofBirth = yearofBirth;

}
 Employee.prototype.calculateAge=function(){
    console.log('The current age is: '+(2019-this.yearofBirth));
    

 }
 console.log(Employee.prototype);

 let emp1 = new Employee('Jack','Tester',1995);
 console.log(emp1);
 emp1.calculateAge();

 let emp2 = new Employee('kane','Software developer',1990);
 console.log(emp2);
 emp2.calculateAge();

 let emp3 = new Employee('John','HR',1993);
 console.log(emp3);
 emp3.calculateAge();
